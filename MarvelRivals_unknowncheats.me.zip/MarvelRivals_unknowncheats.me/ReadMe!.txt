unknowncheats.me 
(TriggerBot & Aim Assist)

TriggerBot = F1
Aim Assist = F2

Resolution: (Windowed Full Screen)

Note: Please ensure these actions are performed without altering the resolution settings.

Best Heros:
- Black Widow
- Hela
- Thor
- Moon Knight
- Peni Parker
- Winter Soldier

There are three color presets available:
- Purple
- Pinkish-Purple