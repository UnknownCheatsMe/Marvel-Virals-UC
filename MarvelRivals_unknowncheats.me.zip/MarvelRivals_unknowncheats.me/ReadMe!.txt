unknowncheats.me @(TriggerBot & Aim Assist)

Active Key:
- TriggerBot = F1
- Aim Assist = F2

Resolution: (Windowed Full Screen)
Note: Please ensure these actions are performed without altering the resolution settings.

Steps 
[ + ] - Start Cheat and Open Game
[ + ] - Select your TriggerBot Choose (Auto/Hotkey)

Best Heros:
- Black Widow
- Hela
- Thor
- Moon Knight
- Peni Parker
- Winter Soldier

(GameSettings->Accessiblity->Enemy_color)
There are three color presets available:
- Purple
- Pinkish-Purple



